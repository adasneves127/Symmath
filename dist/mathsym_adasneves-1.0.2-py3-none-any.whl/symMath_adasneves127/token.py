class token:
    def __init__(self, type, value):
        self.type = type
        self.value = value